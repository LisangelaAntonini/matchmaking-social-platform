from src.models.user import db

class Organization(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    cnpj = db.Column(db.String(18), unique=True, nullable=False)
    responsible_name = db.Column(db.String(120), nullable=False)
    contact_email = db.Column(db.String(120), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

    # 5 Critérios de Avaliação para OSCs
    project_link = db.Column(db.String(255), nullable=True)
    technical_partnerships = db.Column(db.String(20), nullable=True) # yes, no, partially
    partners = db.Column(db.String(255), nullable=True)
    monitoring_plan = db.Column(db.Text, nullable=True)
    social_transformation = db.Column(db.Text, nullable=True)
    innovation = db.Column(db.Text, nullable=True)
    project_name = db.Column(db.String(120), nullable=True)


    def __repr__(self):
        return f"<Organization {self.name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "cnpj": self.cnpj,
            "responsible_name": self.responsible_name,
            "contact_email": self.contact_email,
            "user_id": self.user_id,
            "project_link": self.project_link,
            "technical_partnerships": self.technical_partnerships,
            "partners": self.partners,
            "monitoring_plan": self.monitoring_plan,
            "social_transformation": self.social_transformation,
            "innovation": self.innovation,
            "project_name": self.project_name
        }

