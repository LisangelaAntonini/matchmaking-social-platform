from src.models.user import db

class Evaluation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey("company.id"), nullable=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organization.id"), nullable=True)
    score = db.Column(db.Float, nullable=False)
    comments = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return f"<Evaluation {self.id}>"

    def to_dict(self):
        return {
            "id": self.id,
            "company_id": self.company_id,
            "organization_id": self.organization_id,
            "score": self.score,
            "comments": self.comments,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

