from src.models.user import db

class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    cnpj = db.Column(db.String(18), unique=True, nullable=False)
    responsible_name = db.Column(db.String(120), nullable=False)
    contact_email = db.Column(db.String(120), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

    # 5 Critérios de Avaliação para Empresas
    area_of_operation = db.Column(db.Integer, nullable=True)
    social_impact = db.Column(db.Integer, nullable=True)
    sustainability_goals = db.Column(db.Integer, nullable=True)
    target_audience = db.Column(db.Integer, nullable=True)
    partnership_format = db.Column(db.Integer, nullable=True)


    def __repr__(self):
        return f"<Company {self.name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "cnpj": self.cnpj,
            "responsible_name": self.responsible_name,
            "contact_email": self.contact_email,
            "user_id": self.user_id,
            "criteria": {
                "area_of_operation": self.area_of_operation,
                "social_impact": self.social_impact,
                "sustainability_goals": self.sustainability_goals,
                "target_audience": self.target_audience,
                "partnership_format": self.partnership_format
            }
        }

