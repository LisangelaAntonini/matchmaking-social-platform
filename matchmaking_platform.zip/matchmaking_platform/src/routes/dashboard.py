from flask import Blueprint, jsonify, session
from src.models.user import User
from src.models.company import Company
from src.models.organization import Organization
from src.models.project import Project

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard/stats', methods=['GET'])
def get_stats():
    if 'user_id' not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    stats = {
        "total_companies": Company.query.count(),
        "total_organizations": Organization.query.count(),
        "total_projects": Project.query.count(),
        "total_users": User.query.count()
    }
    
    return jsonify(stats), 200

