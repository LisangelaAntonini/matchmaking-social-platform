from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.evaluation import Evaluation
from datetime import datetime

evaluation_bp = Blueprint('evaluation', __name__)

@evaluation_bp.route('/api/evaluations', methods=['GET'])
def get_evaluations():
    evaluations = Evaluation.query.all()
    return jsonify([evaluation.to_dict() for evaluation in evaluations]), 200

@evaluation_bp.route('/api/evaluations', methods=['POST'])
def create_evaluation():
    data = request.get_json()
    
    evaluation = Evaluation(
        company_id=data.get('company_id'),
        organization_id=data.get('organization_id'),
        score=data['score'],
        comments=data.get('comments'),
        created_at=datetime.utcnow()
    )
    
    db.session.add(evaluation)
    db.session.commit()
    
    return jsonify({"message": "Evaluation created successfully", "evaluation": evaluation.to_dict()}), 201

