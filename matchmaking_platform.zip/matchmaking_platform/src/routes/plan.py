from flask import Blueprint, request, jsonify, session
from src.models.user import db
from src.models.plan import Plan
from datetime import datetime

plan_bp = Blueprint('plan', __name__)

@plan_bp.route('/plans', methods=['GET'])
def get_plans():
    if 'user_id' not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    plans = Plan.query.filter_by(user_id=session['user_id']).all()
    return jsonify([plan.to_dict() for plan in plans]), 200

@plan_bp.route('/plans', methods=['POST'])
def create_plan():
    if 'user_id' not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    data = request.get_json()
    
    plan = Plan(
        user_id=session['user_id'],
        plan_type=data['plan_type'],
        start_date=datetime.utcnow(),
        is_active=True
    )
    
    db.session.add(plan)
    db.session.commit()
    
    return jsonify({"message": "Plan created successfully", "plan": plan.to_dict()}), 201

