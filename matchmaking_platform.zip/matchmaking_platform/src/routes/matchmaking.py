from flask import Blueprint, jsonify
from src.models.company import Company
from src.models.organization import Organization

matchmaking_bp = Blueprint('matchmaking', __name__)

@matchmaking_bp.route('/matchmaking', methods=['GET'])
def get_matches():
    # Simple matchmaking logic - can be enhanced later
    companies = Company.query.all()
    organizations = Organization.query.all()
    
    matches = []
    for company in companies:
        for org in organizations:
            # Calculate a simple compatibility score
            score = 0
            if company.area_of_operation:
                score += company.area_of_operation
            if company.social_impact:
                score += company.social_impact
            
            matches.append({
                "company": company.to_dict(),
                "organization": org.to_dict(),
                "compatibility_score": score / 10  # Normalize to 0-1
            })
    
    # Sort by compatibility score
    matches.sort(key=lambda x: x['compatibility_score'], reverse=True)
    
    return jsonify(matches), 200

