from flask import Blueprint, request, jsonify, session
from src.models.user import db, User
from src.models.organization import Organization

organization_bp = Blueprint('organization', __name__)

@organization_bp.route('/register/organization', methods=['POST'])
def register_organization():
    data = request.get_json()
    
    # Create user first
    if User.query.filter_by(username=data['username']).first():
        return jsonify({"error": "Username already exists"}), 400
    
    user = User(
        username=data['username'],
        email=data['contact_email'],
        user_type='organization'
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.flush()
    
    # Create organization
    organization = Organization(
        name=data['name'],
        cnpj=data['cnpj'],
        responsible_name=data['responsible_name'],
        contact_email=data['contact_email'],
        user_id=user.id,
        project_link=data.get('project_link'),
        technical_partnerships=data.get('technical_partnerships'),
        partners=data.get('partners'),
        monitoring_plan=data.get('monitoring_plan'),
        social_transformation=data.get('social_transformation'),
        innovation=data.get('innovation'),
        project_name=data.get('project_name')
    )
    
    db.session.add(organization)
    db.session.commit()
    
    session['user_id'] = user.id
    session['username'] = user.username
    session['user_type'] = user.user_type
    
    return jsonify({"message": "Organization registered successfully", "organization": organization.to_dict()}), 201

@organization_bp.route('/organizations', methods=['GET'])
def get_organizations():
    organizations = Organization.query.all()
    return jsonify([org.to_dict() for org in organizations]), 200

@organization_bp.route('/organizations/<int:org_id>', methods=['GET'])
def get_organization(org_id):
    organization = Organization.query.get_or_404(org_id)
    return jsonify(organization.to_dict()), 200

