from flask import Blueprint, request, jsonify, session
from src.models.user import db, User
from src.models.company import Company

company_bp = Blueprint('company', __name__)

@company_bp.route('/register/company', methods=['POST'])
def register_company():
    data = request.get_json()
    
    # Create user first
    if User.query.filter_by(username=data['username']).first():
        return jsonify({"error": "Username already exists"}), 400
    
    user = User(
        username=data['username'],
        email=data['contact_email'],
        user_type='company'
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.flush()
    
    # Create company
    company = Company(
        name=data['name'],
        cnpj=data['cnpj'],
        responsible_name=data['responsible_name'],
        contact_email=data['contact_email'],
        user_id=user.id,
        area_of_operation=data.get('area_of_operation'),
        social_impact=data.get('social_impact'),
        sustainability_goals=data.get('sustainability_goals'),
        target_audience=data.get('target_audience'),
        partnership_format=data.get('partnership_format')
    )
    
    db.session.add(company)
    db.session.commit()
    
    session['user_id'] = user.id
    session['username'] = user.username
    session['user_type'] = user.user_type
    
    return jsonify({"message": "Company registered successfully", "company": company.to_dict()}), 201

@company_bp.route('/companies', methods=['GET'])
def get_companies():
    companies = Company.query.all()
    return jsonify([company.to_dict() for company in companies]), 200

@company_bp.route('/companies/<int:company_id>', methods=['GET'])
def get_company(company_id):
    company = Company.query.get_or_404(company_id)
    return jsonify(company.to_dict()), 200

